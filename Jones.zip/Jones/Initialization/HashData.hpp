#pragma once

#include <vector>
#include <iostream>

class HashData {
public:
    static size_t hashData(const std::vector<int>& data);
    static bool fonctionCheckPoint;
};